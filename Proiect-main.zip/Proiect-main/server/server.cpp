#include <iostream>
#include <thread>
#include <string>
#include <sstream>
#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/asio/thread_pool.hpp>
#include <boost/asio/post.hpp>
#include <mutex>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>

using boost::property_tree::ptree;
using namespace boost::asio;
using namespace boost::archive;
using namespace std;
using ip::tcp;
using std::string;
using std::cout;
using std::endl;
boost::asio::thread_pool pool(4);
boost::asio::io_service io_ser;
std::mutex m;
boost::asio::io_service::work work(io_ser);
      tcp::acceptor acceptor_(io_ser, tcp::endpoint(tcp::v4(), 5000));

string xml_file = "..//Proiect/server/sample.xml";

string read_(tcp::socket & socket)
 {
       boost::asio::streambuf buf;
       boost::asio::read_until( socket, buf, "\n" );
       string data = boost::asio::buffer_cast<const char*>(buf.data());
       return data;
}

void send_(tcp::socket & socket, const string &message) 
{
       boost::asio::write( socket, boost::asio::buffer(message));
}

string parse_xml(string &xml_file) {
      string nume, tip, total;
      int cont = 0;
      ptree pt;
      
      read_xml(xml_file, pt);
      BOOST_FOREACH(ptree::value_type & child,pt.get_child("EmployeesData.Employees"))
      {     nume = child.second.get<string>("<xmlattr>.Name") + " ";
            tip = child.second.get<string>("<xmlattr>.Type") + " ";
            total = total + nume + tip;
            cont += 2;
      }
      string s = to_string(cont);
      total = total + s;

      return  std::string(total);
}

void my_task(tcp::socket *socket_i)
{
      string total;

      m.lock();
      total = parse_xml(xml_file);
      m.unlock();

      send_(*socket_i, total);

      delete socket_i;
}

int main() 
{
      tcp::socket *socket_i = new tcp::socket(io_ser);

      cout << "Server started" << endl;
      
      do {
            //waiting for connection
            acceptor_.accept(*socket_i);
            string message = read_(*socket_i);
            if (!message.empty()) {
                  string substring = message.substr(10, message.size() - 11); //get the client name
                  cout << substring << "connected" << endl;
                  boost::asio::post(pool, std::bind(my_task, socket_i));
                  socket_i = new tcp::socket(io_ser);
            }
                  
      } while (1);

      pool.join();

      return 0;
}
