#include <iostream>
#include <boost/asio.hpp>
#include <bits/stdc++.h>
#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include <cstring>
#include <string>
#include <sstream>

using namespace boost::asio;
using namespace boost::archive;
using boost::property_tree::ptree;
using namespace std;
using ip::tcp;
using std::string;
using std::cout;
using std::endl;

void create_xml(const char* vec[],int angajati,string temporarymessage)
{
    ptree mypt;
    ptree mychild;
    int k=0;
    mypt.add("EmployeesData.<xmlattr>.FormatVersion", "1");
    for(int i=0;i<angajati;i++)
        {
            mychild.add("<xmlattr>.Name",vec[k]);
            mychild.add("<xmlattr>.Type",vec[k+1]);
            mypt.add_child("EmployeesData.Employees.Employee",mychild);
            mychild.clear();
            k+=2;
        }
    string filename;
    filename=temporarymessage+".xml";
    cout<<filename<<'\n';
    write_xml(filename,mypt);
    
}

int get_employee(const char* data)
{
    char* sir=(char*)data;
                int elemente;
                char *p = strrchr(sir, ' ');
                elemente=(atoi)(p+1);
return elemente;
}

int main(int argc, char *argv[])
 {

    string msg = "Hello from Client";
    string temporarymessage;
    for(int i=0;i<argc-1;i++)
        {
            temporarymessage=temporarymessage+" "+argv[i+1];
        } 
    msg=msg+temporarymessage+"\n";
    boost::asio::io_service io_service;
    //socket creation
    tcp::socket socket(io_service);
    //connection
    socket.connect( tcp::endpoint( boost::asio::ip::address::from_string("127.0.0.1"), 5000 ));
    //request/message from client
    
    boost::system::error_code error;
    boost::asio::write( socket, boost::asio::buffer(msg), error );
    
    if( !error )
     {
        cout << "Client"<<temporarymessage<<" sent hello message to server!"<< endl;
        
     }
     else 
        {
            cout << "send failed: " << error.message() << endl;
        }

    // getting response from server
    boost::asio::streambuf receive_buffer;
    boost::asio::read(socket, receive_buffer, boost::asio::transfer_all(), error);
    if( error && error != boost::asio::error::eof ) 
        {
            cout << "receive failed: " << error.message() << endl;
        }
        else
            {
                const char* data = boost::asio::buffer_cast<const char*>(receive_buffer.data());
                int angajati,elemente;
                char* sir=(char*)data;
                elemente=get_employee(data);
                angajati=elemente/2;
                const char* vec[angajati*2];
                vec[0]=std::strtok(sir,"  \n");
                for(int i=1;i<elemente;i++)
                    {
                        vec[i]=std::strtok(nullptr," \n");
                    }   
                create_xml(vec,angajati,temporarymessage);
            }



return 0;
}
